﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;


public class inGameUI : MonoBehaviour
{
    //default game is Not paused 
    public static bool GameIsPaused = false;
    //assign setting manu UI
    public GameObject settingMenuUI;

  

    public GameObject audioUI;
    public GameObject buttonUI;

    // Update is called once per frame
    void Update()
    {
        //pause game
        //if press key 
        if (Input.GetKeyDown(KeyCode.Escape))
        {
            //if the game is paused
            if (GameIsPaused)
            {
                Resume();
            }
            //if the game is not paused
            else
            {
                Pause();
            }
        }
       


    }

    public void AppearSettingUI()
    {
        //active the pause menu ui
        settingMenuUI.SetActive(true);
        //pause the time
        Time.timeScale = 0f;
        //change the status to true
        GameIsPaused = true;
    }


    public void Resume()
    {
        //set the pause menu ui to disable
        settingMenuUI.SetActive(false);
        //resume the time
        Time.timeScale = 1f;
        //change the status to false
        GameIsPaused = false;
    }

    public void Pause()
    {
        //active the pause menu ui
        settingMenuUI.SetActive(true);
        //pause the time
        Time.timeScale = 0f;
        //change the status to true
        GameIsPaused = true;
    }

    public void Restart()
    {
        //set the pause menu ui to disable
        settingMenuUI.SetActive(false);
        //resume the time
        Time.timeScale = 1f;
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
        //change the status to false
        GameIsPaused = false;
    }

    public void Home()
    {
        //set the pause menu ui to disable
        settingMenuUI.SetActive(false);
        //resume the time
        Time.timeScale = 1f;
        SceneManager.LoadScene(0);
        //change the status to false
        GameIsPaused = false;
    }

 

    public void AudioSetting()
    {
        //active the pause menu ui
        audioUI.SetActive(true);
        buttonUI.SetActive(false);
        //pause the time
        Time.timeScale = 0f;
        //change the status to true
        GameIsPaused = true;
    }

    public void back()
    {
        //active the pause menu ui
        buttonUI.SetActive(true);
        audioUI.SetActive(false);
        //pause the time
        Time.timeScale = 0f;
        //change the status to true
        GameIsPaused = true;
    }
}
